export type * from "./stylua.web/stylua_lib";
export declare const initSync: never;
