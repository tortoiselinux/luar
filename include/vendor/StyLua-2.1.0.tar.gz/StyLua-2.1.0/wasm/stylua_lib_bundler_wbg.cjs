module.exports = require("./stylua.web/stylua_lib.js").__getImports().wbg;
