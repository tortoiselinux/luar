#!/usr/bin/env node

const { install } = require("./binary");
install();
