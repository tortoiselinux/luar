#!/usr/bin/env node

const { uninstall } = require("./binary");
uninstall();
