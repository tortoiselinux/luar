call()
call(1)
call(1, 2)