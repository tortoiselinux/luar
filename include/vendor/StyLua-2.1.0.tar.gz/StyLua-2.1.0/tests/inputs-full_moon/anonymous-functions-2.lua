call(function()
	foo("bar")
end)