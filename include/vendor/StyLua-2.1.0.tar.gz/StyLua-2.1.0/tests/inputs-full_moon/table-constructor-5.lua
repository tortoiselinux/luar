local x = {
	[call()] = 1,
	2,
}