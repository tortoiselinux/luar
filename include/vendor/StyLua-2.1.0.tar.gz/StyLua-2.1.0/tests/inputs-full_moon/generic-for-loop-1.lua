for index, value in pairs(list) do
	call(index, value)
end