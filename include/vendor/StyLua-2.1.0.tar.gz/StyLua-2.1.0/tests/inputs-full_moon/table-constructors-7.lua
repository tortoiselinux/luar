local blacklist = {
	["Audio file failed to load (18)."] = true;
	["HTTP 0 (HTTP 429 (HTTP/1.1 429 ProvisionedThroughputExceeded))"] = true;
	["LoadCharacter can only be called when Player is in the world"] = true;
}