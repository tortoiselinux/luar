if x then
	call()
end