local num = 0.5
local num2 = 0.5e5
local num3 = .5
local num4 = .5e5
local num5 = 1.
