local x = {
	a = 1,
	b = 2,
	c = 3
}

local y = {
	a = 1,
	b = 2,
	c = 3,
}