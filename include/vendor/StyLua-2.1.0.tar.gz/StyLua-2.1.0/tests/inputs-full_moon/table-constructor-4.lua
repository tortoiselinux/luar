local x = {
	[call()] = 1,
}