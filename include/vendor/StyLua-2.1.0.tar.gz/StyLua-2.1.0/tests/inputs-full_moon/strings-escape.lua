call('\\')
call("\\")
call({ ["\\"] = "" })