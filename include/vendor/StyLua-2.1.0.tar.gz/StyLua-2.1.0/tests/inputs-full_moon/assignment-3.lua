-- Crazy assignment code from AmaranthineCodices
a, b, c.d.e[f][g][1], h:i().j[k]:l()[m] = true, false, 1, 4