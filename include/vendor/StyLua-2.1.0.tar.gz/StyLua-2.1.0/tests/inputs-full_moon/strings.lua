call("double")
call('single')
call("foo\nbar")
call("")