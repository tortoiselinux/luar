--[=[

	This description starts one line down,

	And has a line in the middle, followed by trailing lines.

	```lua
	function test()
		print("indentation")

		do
			print("more indented")
		end
	end
	```


	@class indentation


]=]