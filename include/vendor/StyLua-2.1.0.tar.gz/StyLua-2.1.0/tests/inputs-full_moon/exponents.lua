local num = 1e5
local num2 = 1e-5
local num3 = 1e+5