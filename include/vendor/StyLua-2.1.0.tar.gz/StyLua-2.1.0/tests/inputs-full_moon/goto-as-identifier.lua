-- goto as an identifier is permitted in lua 5.1
self.goto("foo")