local x = function()
	call(1)
end
