local a, b = 1, 2
local c, d = 3, 4
local e, f = 5, 6