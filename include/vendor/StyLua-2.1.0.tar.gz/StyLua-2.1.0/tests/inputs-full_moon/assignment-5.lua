gui.Label.Text = "LOADING DATA" .. ("."):rep(dotCount)
