local negativeLiteral = -3
local negativeVariable = -x
local notLiteral = not true
local notVariable = not x
local length = #x