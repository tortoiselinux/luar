a = foo and bar
b = foo and bar or baz
c = 1 + 2 * 3 - 4 ^ 2
d = a + i < b / 2 + 1
e = 5 + x ^ 2 * 8
f = a < y and y <= z
g = -x ^ 2
h = x ^ y ^ z