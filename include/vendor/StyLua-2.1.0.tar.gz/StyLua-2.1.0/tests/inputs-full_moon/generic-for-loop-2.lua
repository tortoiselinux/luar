for index, value in next, list do
	call(index, value)
end