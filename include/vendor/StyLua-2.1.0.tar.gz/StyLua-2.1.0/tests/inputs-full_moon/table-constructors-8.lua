return {
	["Noob Attack: Periastron"] = "Noob Attack - Periastron";
	["Noob Attack꞉ Periastron"] = "Noob Attack - Periastron";
}
