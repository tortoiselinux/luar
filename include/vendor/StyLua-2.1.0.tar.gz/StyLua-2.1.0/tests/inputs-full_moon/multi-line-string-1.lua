local x = [[Full Moon
is a
lossless
Lua parser]]