print("foo\
	bar")
