call { x = 1 }
call "hello"