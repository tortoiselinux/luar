while condition do
	call()
	break
end