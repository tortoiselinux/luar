if x then
	foo()
else
	bar()
end