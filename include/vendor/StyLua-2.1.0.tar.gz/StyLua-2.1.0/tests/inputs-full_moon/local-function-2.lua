local function foo(a, b) end
local function bar(...) end
local function baz(a, b, ...) end