local x = [=[This is
several equal
signs]=]