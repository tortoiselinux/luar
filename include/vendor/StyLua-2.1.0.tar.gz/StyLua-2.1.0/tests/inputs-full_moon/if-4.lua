if x then
	foo()
elseif y then
	bar()
else
	baz()
end