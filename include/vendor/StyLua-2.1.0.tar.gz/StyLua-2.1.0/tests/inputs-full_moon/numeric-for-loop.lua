for index = 1, 10 do call(index) end
for _ = start, final do end
for _ = 1, 10, 2 do end