local foo = x-1
local foo = x -1
print(1+-3)
local foo = -x+1