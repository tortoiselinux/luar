do
	return 1
end

do
	break
end

return call()
