#!/usr/bin/env lua

print("Hello world");
