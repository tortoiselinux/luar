local x = 1
-- Then a comment
local y = 1
