-- comments separated by tab chars, should be parsed as trailing trivia of the tokens they are next to
-- stylua: ignore
local too = {
	x,		-- string
	y,		-- string
}
