--[[
local emotes = {
	[":thinking:"] = "http://www.roblox.com/asset/?id=643340245",
	[":bug:"] = "http://www.roblox.com/asset/?id=860037275"
}
]]