local emoji = [[🧓🏽]]
local more_code = here
