local foo = {"bar", "baz", "foo", "bar", "baz", "foo", "bar", "baz", "foo", "bar", "baz", "foo", "bar", "baz", "foo", "bar", "baz"}

local foo = {"bar", "baz", "foo", "bar", "baz", "foo",
	"bar", "baz", "foo", "bar", "baz", "foo", "bar",
	"baz", "foo", "bar", "baz", "foo", "bar", "baz"}

local foo = {

}