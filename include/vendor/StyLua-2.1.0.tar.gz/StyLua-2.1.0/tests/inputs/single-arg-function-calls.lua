do
	do
		do
			do
				do
					do
						jestExpect(ReactIs.typeOf(React.createElement(React.Profiler, { id = "foo", onRender = jest.fn() }))).toBe(ReactIs.Profiler)
					end
				end
			end
		end
	end
end
