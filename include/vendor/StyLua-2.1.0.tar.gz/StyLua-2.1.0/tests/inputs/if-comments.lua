if true then
	-- foo
elseif bar then
	-- bar
else
	-- baz
end