local foo = function(bar, baz) print(foo) end
call(function(x,y) local x = test end)