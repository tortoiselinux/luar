   while    true    do  
	print("foo")
 end