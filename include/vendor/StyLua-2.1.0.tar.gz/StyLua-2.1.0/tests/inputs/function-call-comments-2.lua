-- https://github.com/JohnnyMorganz/StyLua/issues/307#issuecomment-980594322
call(
	param_a -- this is cool
	, param_b
)
