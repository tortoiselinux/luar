function foo()

	local x = 1


	return true

end

function bar()


	return


end

do

	-- comment
	local x = 1


	local foo = bar

	-- comment

end