if (foo) then
	print("true")
elseif (bar) then
	print("false")
end

while (foo) do
	print("true")
end

repeat
	print("yes")
until (foo)