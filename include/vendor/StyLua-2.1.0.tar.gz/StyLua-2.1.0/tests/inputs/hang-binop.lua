local foo = x ^ -- comment
	y % -- comment
	z - -- comment
	a <= -- comment
	b < -- comment
	c >= -- comment
	d
