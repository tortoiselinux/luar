call "string" 
call {foo='bar',baz=1}  
call  (x,y, z)   