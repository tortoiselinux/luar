-- https://github.com/JohnnyMorganz/StyLua/issues/551
local test = {
	{ "http://example.com/b//c//d;p?q#blarg", "http://u:p@h.com/p/a/t/h?s#hash2", "http://u:p@h.com/p/a/t/h?s#hash2" },
}
