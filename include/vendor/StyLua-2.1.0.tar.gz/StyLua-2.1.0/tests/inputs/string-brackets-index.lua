local foo = {
	[ [[test]] ] = true,
}

foo[ [[test]] ] = false
