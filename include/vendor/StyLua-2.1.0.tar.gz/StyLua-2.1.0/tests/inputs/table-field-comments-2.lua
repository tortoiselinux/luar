-- https://github.com/JohnnyMorganz/StyLua/issues/942
local t = {
	plus_one =
    ---@param n number
	---@return number
    function(n)
		return n + 1
	end  ,
}
