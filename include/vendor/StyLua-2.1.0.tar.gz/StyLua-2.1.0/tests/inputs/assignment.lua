local      foo    =      'bar'       
local   bar       ,       baz     = 1   ,   2    