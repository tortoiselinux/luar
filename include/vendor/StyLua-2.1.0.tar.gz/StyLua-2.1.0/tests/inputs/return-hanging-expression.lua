function foo()
	return fooooooooooooooooooo(barrr) or foooooooooooooooooooooooooooooooooooooooooooooooooooooopppo(barrrrrrrrrrrrrr)(hello) or bazzzzzzzzzzzzzzzzzz
  end

