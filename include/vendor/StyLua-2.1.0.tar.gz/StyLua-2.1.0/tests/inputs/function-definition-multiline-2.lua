-- https://github.com/JohnnyMorganz/StyLua/issues/830
local a_very_long_variable_name_given_that_is_bigger_than_width_upper_limit_but_unfortunately_can_not_be_made_shorter = function()
	print("Hello")
end
