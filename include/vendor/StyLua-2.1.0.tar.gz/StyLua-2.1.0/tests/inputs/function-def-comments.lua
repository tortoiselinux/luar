function func(
	param_a -- description of a
	, param_b -- description of b
) end
