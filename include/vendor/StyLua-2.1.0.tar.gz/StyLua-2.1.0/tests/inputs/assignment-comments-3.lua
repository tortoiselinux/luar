-- https://github.com/JohnnyMorganz/StyLua/issues/662
local a, b
= 1 -- adoc
, 2 -- bdoc

local a -- adoc
, b -- bdoc
= 1, 2
