-- A
a = A()

-- B
.B()

-- C
.C()
