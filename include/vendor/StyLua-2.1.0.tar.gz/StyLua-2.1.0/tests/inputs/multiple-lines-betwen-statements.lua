local x = 1


local y = 2



local z = 3