-- https://github.com/JohnnyMorganz/StyLua/issues/509
local foo = bar -- comment after bar
        .fizz -- comment after fizz
