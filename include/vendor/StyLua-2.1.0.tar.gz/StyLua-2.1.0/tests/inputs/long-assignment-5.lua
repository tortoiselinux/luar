-- https://github.com/JohnnyMorganz/StyLua/issues/292
local musicId, musicTime, responseTick, responseOffset = remotes.Server.GetSpectatorInfo:InvokeServer(player, sendTick, anotherArgument)
