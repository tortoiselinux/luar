local function foo(bar)
	local count = 0

	repeat
		count = count + 1
	until count == 10
end