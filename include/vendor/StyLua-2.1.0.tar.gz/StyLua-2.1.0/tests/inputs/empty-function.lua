local function noop() end

function noop() end

call(function() end)