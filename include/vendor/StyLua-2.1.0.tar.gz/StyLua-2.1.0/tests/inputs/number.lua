local a = 0.5
local b = .5
local c = 100
local d = 5e-5
local e = -.5
local f = .2e-5
local g = -.1e+5
local h = 0x12