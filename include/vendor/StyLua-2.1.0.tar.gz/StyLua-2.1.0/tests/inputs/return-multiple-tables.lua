-- https://github.com/JohnnyMorganz/StyLua/issues/302
return {
	foo = bar,
	foo = bar,
	foo = bar,
	foo = bar,
	foo = bar,
	foo = bar,
	foo = bar,
	foo = bar,
}, {
	bar = baz,
	bar = baz,
	bar = baz,
	bar = baz,
	bar = baz,
	bar = baz,
	bar = baz,
	bar = baz,
}
