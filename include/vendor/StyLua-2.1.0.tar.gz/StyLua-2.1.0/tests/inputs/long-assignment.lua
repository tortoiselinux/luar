local LoadAddOn, UnitName, GetRealmName, UnitRace, UnitFactionGroup, IsInRaid = LoadAddOn, UnitName, GetRealmName, UnitRace, UnitFactionGroup, IsInRaid

LoadAddOn, UnitName, GetRealmName, UnitRace, UnitFactionGroup, IsInRaid = LoadAddOn, UnitName, GetRealmName, UnitRace, UnitFactionGroup, IsInRaid

do
	local LoadAddOn, UnitName, GetRealmName, UnitRace, UnitFactionGroup, IsInRaid = LoadAddOn, UnitName, GetRealmName, UnitRace, UnitFactionGroup, IsInRaid
end

do
	local XOffset, YOffset, ZOffset = CFrame.new(GlobalConfiguration.TPS_CAMERA_OFFSET.X, 0, 0), CFrame.new(0, GlobalConfiguration.TPS_CAMERA_OFFSET.Y, 0), CFrame.new(0, 0, GlobalConfiguration.TPS_CAMERA_OFFSET.Z)
end