local baz = foo(bar);
(foo and x or y)(bar)

function foobar()
	local baz = foo(bar);
	(baz and x or y)(bar)
end
