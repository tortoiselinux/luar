function foo()
	return (
		long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
	), (
		long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
	)
end

function foo()
	return foo and bar or baz, (
		long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
	)
end

function foo()
	return not (
		long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
		+ long_variable_name
	)
end
