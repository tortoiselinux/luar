-- https://github.com/JohnnyMorganz/StyLua/issues/431
local Packages; --[[ ROBLOX comment: must define Packages module ]]
local boo = --[[a comment]]
require(Packages.foo)
--[[another comment]];
--[[yet another comment]]
