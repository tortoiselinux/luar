local foo = a <= b --[[ some block comment ]]; -- inline comment
fn() --[[ some block comment 2 ]]; -- inline comment 2
