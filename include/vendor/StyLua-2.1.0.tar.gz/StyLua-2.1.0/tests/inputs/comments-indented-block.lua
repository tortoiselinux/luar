function foo()
    local x = 1
    local y = 1

    -- comment
end

if foo then
    local x = 1
    -- comment
end