do
	local HitPart, HitPoint, HitNormal, HitMaterial = nil, Ray.Origin + Ray.Direction, Vector3.new(0, 1, 0), Enum.Material.Air
end