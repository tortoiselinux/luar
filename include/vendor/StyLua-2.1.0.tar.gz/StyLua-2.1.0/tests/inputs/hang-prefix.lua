("foooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo" .. "barrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"):format()

do
	("foooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo" .. "barrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"):format()
end

print(("foooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo" .. "barrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr"):format())