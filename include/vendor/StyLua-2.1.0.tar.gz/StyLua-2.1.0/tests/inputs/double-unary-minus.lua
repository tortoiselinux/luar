local x = -(-foo)
local y = - -foo

local z1 = -(-foo) -- bar
local z2 = - -foo -- baz