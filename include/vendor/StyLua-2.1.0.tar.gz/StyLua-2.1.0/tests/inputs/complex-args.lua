React.createElement("span", { key = id }, React.createElement(Consumer, nil, function()
	return React.createElement("span", nil, "inner")
end), React.createElement("span", nil, "outer"))