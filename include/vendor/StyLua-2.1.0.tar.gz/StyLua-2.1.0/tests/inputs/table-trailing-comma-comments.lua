-- https://github.com/JohnnyMorganz/StyLua/issues/547
local too = {
	x,		-- string
	y		-- string
}
