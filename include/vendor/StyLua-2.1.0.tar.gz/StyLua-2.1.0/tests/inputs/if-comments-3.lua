if true then
else
end

if true then


	-- this is a comment


-- but this is another comment
	-- and another one - we should hence indent the comments overall
else
end
