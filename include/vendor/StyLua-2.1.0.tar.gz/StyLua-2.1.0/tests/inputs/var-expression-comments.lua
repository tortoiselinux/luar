-- https://github.com/JohnnyMorganz/StyLua/issues/500
local foo = bar
  -- comment 1
  .fizz
  -- comment 2
  .buzz
