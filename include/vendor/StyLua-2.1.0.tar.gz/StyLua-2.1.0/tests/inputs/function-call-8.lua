function_call(("hello" .. "darkness" .. "my" .. "old" .. "friend" .. "hello" .. "darkness" .. "my" .. "old" .. "friend" .. "!!!!!!!!!!!!"):call())
