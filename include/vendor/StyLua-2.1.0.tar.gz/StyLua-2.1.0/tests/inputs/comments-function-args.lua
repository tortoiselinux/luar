foo( -- comment
baz
)

foo(
baz, -- comment
bar
)

foo (
	baz,
	-- comment
	bar
)

foo(baz, 
bar -- comment
)

foo(baz, bar) -- comment

foo(
	-- comment
	baz,
	bar
)
