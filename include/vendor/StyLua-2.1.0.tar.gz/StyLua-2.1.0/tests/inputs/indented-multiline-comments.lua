function foo()
    function bar()
        function baz()
            --[[
                comment
            ]]
            local x = 1
        end
    end
end