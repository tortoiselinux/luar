-- https://github.com/JohnnyMorganz/StyLua/issues/747

obj. --
func(). --
func(). --
func()
