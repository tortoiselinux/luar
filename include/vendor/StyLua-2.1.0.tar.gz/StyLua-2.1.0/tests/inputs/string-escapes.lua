local foo = 'this \'string\' has \'escaped\' single quotes with "double quotes"'
local bar = "test \'foo\' \"bar\""
local baz = '\\"""'