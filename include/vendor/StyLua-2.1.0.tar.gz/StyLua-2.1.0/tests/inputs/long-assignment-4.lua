do
	do
		local FrontDistanceX, FrontDistanceY =
			self.settings.FWsBoneLen * math.cos(math.rad(self.settings.FWsBoneAngle)),
			self.settings.FWsBoneLen * math.sin(math.rad(self.settings.FWsBoneAngle))
	end
end
