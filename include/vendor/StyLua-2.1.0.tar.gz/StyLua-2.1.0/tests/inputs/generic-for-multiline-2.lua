-- https://github.com/JohnnyMorganz/StyLua/issues/579
for _, item in
	-- comment
	call()
do
end


for _, item in -- comment
	call()
do
end


for _, item in           -- comment

	call()
do
end
