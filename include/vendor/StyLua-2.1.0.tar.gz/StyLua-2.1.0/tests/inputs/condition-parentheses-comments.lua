-- https://github.com/JohnnyMorganz/StyLua/issues/389
repeat
	x = x + 1
until (x + y < 2) -- comment
