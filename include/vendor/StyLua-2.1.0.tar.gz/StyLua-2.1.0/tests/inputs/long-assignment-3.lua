local something = fooooooooooooooo == barrrrrrrrrrrr and func(arggggggggggggggggggggggggggggggggggggggggg1, argggggggggg2) or somethingeeeeeeeeeeee
