-- https://github.com/JohnnyMorganz/StyLua/issues/436
local OffsetEnum = {aValue = 10, anotherValue = 11, yetAnotherValue = 12, reset = 0, postReset = 1, aaaaaaaaaaa = true}

local OffsetEnum = { aValue = 10, anotherValue = 11, yetAnotherValue = 12, reset = 0, postReset = 1, aaaaaaaaa = true }
