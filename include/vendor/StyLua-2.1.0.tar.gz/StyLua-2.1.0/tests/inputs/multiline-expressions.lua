if someReallyLongCondition and someOtherReallyLongCondition and somethingElse and someReallyLongCondition and someOtherReallyLongCondition and somethingElse then
    print("foo")
end

foo = someReallyLongCondition * someOtherReallyLongCondition * somethingElse * someReallyLongCondition * someOtherReallyLongCondition * somethingElse

local foo = someReallyLongCondition and someOtherReallyLongCondition == foo and somethingElse and someReallyLongCondition and someOtherReallyLongCondition and somethingElse

repeat print("foo") until someReallyLongCondition and someOtherReallyLongCondition and somethingElse and someReallyLongCondition and someOtherReallyLongCondition and somethingElse

while someReallyLongCondition and someOtherReallyLongCondition and somethingElse and someReallyLongCondition and someOtherReallyLongCondition and somethingElse do
    print("foo")
end

if foo(aVeryLongValue, anotherVeryLongValue, someEvenMoreLongValues, evenMoreLongValues, whenWillTheseLongValuesEverEnd) and someOtherReallyLongCondition and somethingElse and someReallyLongCondition and someOtherReallyLongCondition and somethingElse then
    print("foo")
end

baz(first_arg___ooooooooooooooooooooooooooooooooooooooooooo, second_arg___qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq, function() if
			multiline_if___aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
			and multiline_if___bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb
	then
			foo()
		end
	end
)