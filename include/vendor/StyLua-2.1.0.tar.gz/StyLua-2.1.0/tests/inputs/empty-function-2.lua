local function noop() -- comment
end

function noop()
	-- comment
end

call(function()
	-- comment

end)