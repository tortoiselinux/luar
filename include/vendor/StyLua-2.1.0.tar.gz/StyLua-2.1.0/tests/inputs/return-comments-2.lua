-- https://github.com/JohnnyMorganz/StyLua/issues/662
function f()
	return a -- adoc
		, b -- bdoc
end
