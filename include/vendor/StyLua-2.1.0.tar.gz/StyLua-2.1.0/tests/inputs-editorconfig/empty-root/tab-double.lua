local foo = {
	a = 1,
}

local bar = ""
