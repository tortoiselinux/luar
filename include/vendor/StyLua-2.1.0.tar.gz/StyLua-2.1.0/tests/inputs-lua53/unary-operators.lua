local x = ~1
