local a = 1 & 2
local b = 1 | 2
local c = 1 << 2
local d = 1 >> 2
local e = 1 ~ 2
local f = 1 // 2
