local foo     =      bar
do
    -- stylua: ignore start
    local bar   =     baz
    local bar   =     baz
end
local bar   =     baz
