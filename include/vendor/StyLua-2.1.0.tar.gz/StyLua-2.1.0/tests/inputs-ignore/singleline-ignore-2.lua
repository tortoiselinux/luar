local foo     =      bar
-- stylua: ignore
local bar   =     baz
local bar   =     baz
