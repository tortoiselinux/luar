local   x     = 1
-- stylua: ignore
function foo   ()
    return    x +    1
end
