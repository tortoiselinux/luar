local foo     =      bar
-- stylua: ignore start
local bar   =     baz
local bar   =     baz
local bar   =     baz
