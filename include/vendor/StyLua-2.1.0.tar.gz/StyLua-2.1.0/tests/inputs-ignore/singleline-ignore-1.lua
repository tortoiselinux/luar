local foo     =      bar
-- stylua: ignore
local bar   =     baz
