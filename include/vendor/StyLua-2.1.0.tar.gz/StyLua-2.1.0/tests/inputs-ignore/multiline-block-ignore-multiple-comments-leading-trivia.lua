--stylua: ignore start
local a   =   1
--stylua: ignore end

--stylua: ignore start
local b   =   2
--stylua: ignore end

--stylua: ignore start
local c   =   3
--stylua: ignore end

-- Some very large comment

--stylua: ignore start
local d   =   4
--stylua: ignore end
