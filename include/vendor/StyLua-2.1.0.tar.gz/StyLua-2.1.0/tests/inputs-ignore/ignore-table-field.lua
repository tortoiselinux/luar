local foo = {
	-- stylua: ignore
	x   =    2,
	y  =  3,
	z        =   " he "  ,
}

local bar = {
	x   =    2,
	-- stylua: ignore
	y  =  3,
	z        =   " he "  ,
}

local baz = {
	x   =    2,
	y  =  3,
	-- stylua: ignore
	z        =   " he "  ,
}
