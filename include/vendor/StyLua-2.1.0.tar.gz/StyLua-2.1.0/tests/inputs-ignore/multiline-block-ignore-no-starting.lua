local foo     =      bar
local bar   =     baz
local bar   =     baz
-- stylua: ignore end
local bar   =     baz
