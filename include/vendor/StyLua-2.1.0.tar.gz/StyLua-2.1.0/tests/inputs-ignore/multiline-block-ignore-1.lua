local foo     =      bar
-- stylua: ignore start
local bar   =     baz
-- stylua: ignore end
local bar   =     baz
