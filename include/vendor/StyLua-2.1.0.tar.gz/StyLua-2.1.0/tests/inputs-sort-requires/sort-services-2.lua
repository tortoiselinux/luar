-- Requires should be treated as a separate group to services
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local CollectionService = game:GetService("CollectionService")
local C = require("C")
local A = require("A")
