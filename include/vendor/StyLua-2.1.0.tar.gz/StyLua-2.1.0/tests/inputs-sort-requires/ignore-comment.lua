-- stylua: ignore
local c   = require("c")
local b = require("b")
local a = require("a")

local c = require("c")
-- stylua: ignore
local b   = require("b")
local a = require("a")

local c = require("c")
local b = require("b")
-- stylua: ignore
local a   = require("a")
