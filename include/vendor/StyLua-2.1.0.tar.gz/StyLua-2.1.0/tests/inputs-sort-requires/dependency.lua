local parent = script.Parent
local x = foo()
local bee = require("aaa")
local cee = require(parent.Cee)
local aaa = require(parent.Script)

print("hello world")
