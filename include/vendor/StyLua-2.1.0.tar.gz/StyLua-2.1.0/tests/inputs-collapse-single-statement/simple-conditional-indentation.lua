for i = 1, 10 do
	if true then
		return
	end
end
