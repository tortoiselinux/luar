-- https://github.com/JohnnyMorganz/StyLua/issues/619
local a = {
	aa = function() return "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" end,
}
