local x = function()
	call("testing")
end
