local x = function()
	x = 1
end
