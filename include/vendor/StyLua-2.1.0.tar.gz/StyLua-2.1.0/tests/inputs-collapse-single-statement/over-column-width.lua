function MiniCompletion.default_process_items(items, base)
  return H.default_config.lsp_completion.process_items(items, base)
end
