local x = function()
	local x = 1
end
