if true then
	call("hello")
end
