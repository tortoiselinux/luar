function foo()
    return bar
end

