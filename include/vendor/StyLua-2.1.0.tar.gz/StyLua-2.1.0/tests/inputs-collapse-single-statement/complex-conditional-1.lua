if child == nil then
    child, index = index, #self + 1
end
