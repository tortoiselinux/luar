-- https://github.com/JohnnyMorganz/StyLua/issues/744

if tabnr ~= finaltab then

	stack:push('%T')
end
