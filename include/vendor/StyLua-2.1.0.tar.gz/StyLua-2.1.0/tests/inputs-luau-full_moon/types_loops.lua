for i, v: string in pairs() do

end

for i: number = 1, 10, 2 do
    
end