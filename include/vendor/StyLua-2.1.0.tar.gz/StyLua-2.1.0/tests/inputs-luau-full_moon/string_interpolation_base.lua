x(`simple`)
x(`hello {"world"}`)
x(`1{2}3{"4"}5`)
x(`1{`2{"3"}`}`)
