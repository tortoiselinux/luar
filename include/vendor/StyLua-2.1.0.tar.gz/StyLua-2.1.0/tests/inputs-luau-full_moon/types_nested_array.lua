type Foo = { { string } }
type Foo = { {Name: string, Foo: number} }