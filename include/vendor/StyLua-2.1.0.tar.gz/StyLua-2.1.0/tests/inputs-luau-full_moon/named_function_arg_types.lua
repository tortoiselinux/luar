type MyCallbackType = (cost: number, name: string) -> string

local cb: (amount: number) -> number
local function foo(cb: (name: string) -> ())
end

local function bar(x: (number)?): (baz: string) -> string
end

local function bar(x: (number)?): (baz: string) -> ((names: Array<string>) -> ...any)
end