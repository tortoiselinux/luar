type Bar = Foo<>
type Baz = module.Foo<>