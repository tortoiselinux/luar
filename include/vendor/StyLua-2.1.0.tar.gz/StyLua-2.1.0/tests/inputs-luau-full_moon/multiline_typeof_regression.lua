type TypeOf =
    typeof({})
