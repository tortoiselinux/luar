local _ = `{ {}}`
local _ = `{--[[]]{}}`
local _ = `\{{true}`
local _ = `{ {true}}`
-- TODO: https://github.com/Roblox/luau/issues/1019
-- local _ = `{ {hello}}`
local _ = `\{{hello}}`