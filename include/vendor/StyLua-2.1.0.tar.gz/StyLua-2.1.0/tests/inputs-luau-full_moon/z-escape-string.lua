print("testing \z
	   twelve")

print("Hello \
	World")

print(`testing \z
	   twelve`)

print(`Hello \
	World`)
