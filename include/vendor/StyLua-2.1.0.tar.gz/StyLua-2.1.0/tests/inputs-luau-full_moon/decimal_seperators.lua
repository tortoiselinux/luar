local num1 = 1_048_576
local num2 = 0xFFFF_FFFF
local num3 = 0b_0101_0101
local num4 = 1_523_423.132_452_312
local num5 = 1e512_412
local num6 = 1e-512_412