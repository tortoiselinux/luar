-- Very important loop here
while true do
	continue
end

continue()
local continue = 4
