type Config = {
    option1: string??, -- you probably need it once in a while
    option2: string???, -- once a year
    option3: string?????? -- once in your life!
}