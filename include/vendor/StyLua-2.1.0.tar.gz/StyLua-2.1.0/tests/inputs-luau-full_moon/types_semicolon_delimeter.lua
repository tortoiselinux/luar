type Foo = {
	bar: number;
	baz: number;
}