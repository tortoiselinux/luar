error(
	`a {b} c`
)
