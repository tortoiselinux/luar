type Array<T> = { T }
type Array<T> = { [number]: T }