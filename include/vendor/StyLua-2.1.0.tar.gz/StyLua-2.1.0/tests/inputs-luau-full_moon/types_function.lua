type function f(...)
    -- implementation of the type function
end

export type function f(...)
    -- implementation of the type function
end