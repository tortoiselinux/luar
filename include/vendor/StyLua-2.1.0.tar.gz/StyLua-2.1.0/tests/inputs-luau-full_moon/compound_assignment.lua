local x = 1
local y = 2

x += 5
x -= 5
x *= 5
x /= 5
x //= 5
x %= 5
x ^= 5

x += y
x -= y
x *= y
x /= y
x //= y
x %= y
x ^= y

local str1 = "Hello, "
local str2 = "world!"

str1 ..= "world!"
str1 ..= str2