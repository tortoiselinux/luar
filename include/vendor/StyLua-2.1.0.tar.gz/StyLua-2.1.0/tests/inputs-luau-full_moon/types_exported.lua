type Foo = { bar: any }
export type Baz = { foo: any }
