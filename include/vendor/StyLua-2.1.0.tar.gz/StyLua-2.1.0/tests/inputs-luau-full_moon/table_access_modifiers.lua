type Foo = {
	read bar: number,
	write baz: number,
}