local x: module.Foo = nil
local x: module.Array<string> = { "bar" }
local x: module.Foo | string = "bar"
local x: module.Foo? = nil
local x: module.Foo<...string> = nil