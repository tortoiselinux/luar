local x = if (foo :: number) < bar
	then very + very + very + long + line + right + here + hopefully
	else lets + ensure + stylua + writes + this + out + using + multiple + lines
