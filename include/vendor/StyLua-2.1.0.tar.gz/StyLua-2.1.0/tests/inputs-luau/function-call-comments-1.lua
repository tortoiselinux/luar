do
	for _, foo in
		applyFoooooo(
			aaaaaaaaaaaaaaaaaaaa, --[[:: Array<aaaaaaaaaaaaaaaaa>]]
			bbbbbbbbbbbbbbbbbb --[[:: Array<bbbbbbbbbbbbbbb>]]
		) :: Array<aaaaaaaaaaaaaaaaa | bbbbbbbbbbbbbbb>
	do
	end
end
