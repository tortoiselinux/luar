--- https://github.com/JohnnyMorganz/StyLua/issues/828
type foo = {
	[("bar" | "baz")]: any,
}
