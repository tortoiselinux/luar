@native
function foo()
end

@deprecated
local function bar()
end

local x = @native function()
end
