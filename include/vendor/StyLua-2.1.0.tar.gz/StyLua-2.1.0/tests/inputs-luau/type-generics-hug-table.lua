-- https://github.com/JohnnyMorganz/StyLua/issues/442
export type Store = EventEmitter<{
	collapseNodesByDefault: Array<any>,
	componentFilters: Array<any>,
	mutated: Array<any>, -- ROBLOX deviation: can't express jagged array types in Luau
	recordChangeDescriptions: Array<any>,
	roots: Array<any>,
	supportsNativeStyleEditor: Array<any>,
	supportsProfiling: Array<any>,
	supportsReloadAndProfile: Array<any>,
	unsupportedRendererVersionDetected: Array<any>,
}>
