local function mergeDeep<T...>(...: T...) -- : TupleToIntersection<...T>
	return mergeDeepArray({ ... })
end
