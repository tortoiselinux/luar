local scale = if someReallyLongFlagName() or someOtherReallyLongFlagName() then foo else bar

local scale = if someReallyLongFlagName() or someOtherReallyLongFlagName() then foooooooooooooBarrrrrrrrr else barrrrrrrrrBazzzzzz

local scale = if someReallyLongFlagName() or someOtherReallyLongFlagName() then Vector2.new(1, 1) + someVectorOffset + someOtherVector else Vector2.new(1, 1) + someNewVectorOffset + someNewOtherVector

local scale = if someReallyReallyLongFunctionNameThatForcesTheConditionToSpanMultipleLines() and someOtherReallyLongFunctionNameThatForcesTheConditionToSpanMultipleLines() then 1 else 2

local thing = makeSomething("Foo", {
	OneChild = if someFlag() then
		makeSomething("Bar", {
			scale = 1,
		})
	else
		makeSomething("Bar", {
			scale = 2,
		}),
	TwoChild = makeSomething("Baz"),
})

local thing = makeSomething("Foo", {
	OneChild = if someFlag() then makeSomething("Bar", {
		scale = 1,
	}) else makeSomething("Bar", {
		scale = 2,
	}),
	TwoChild = makeSomething("Baz"),
})

local state = if hook ~= nil then hook.memoizedState elseif typeof(initialState) == "function" then (initialState :: (() -> S))() else initialState

local scale = if someFlag() then 1 elseif someOtherFlag() then 0.5 else 2

local thing = makeSomething("Foo", {
	OneChild = if someFlag()
		then makeSomething("Bar", {
			scale = 1,
		})
		elseif someOtherFlag() then makeSomething("Bar", {
			scale = 0.5,
		})
		else makeSomething("Bar", {
			scale = 2,
		}),
	TwoChild = makeSomething("Baz"),
})
do
	do
	  do
		do
		  console.error(
			"guitarFuzz design functions accept exactly two parameters: guiter and fuzz. %s",
			if argumentCount == 1 then "Did you forget to use the fuzz parameter?" else "Any additional parameter will be undefined."
		  )
		end
	  end
  end
end
