export type Thenable<R, U> = {
	andTheeeeeeeeeeeeeeen: (any, (R) -> () | Thenable<R, U> | U, (any) -> () | Thenable<R, U> | U) -> () | Thenable<R, U>,
}
