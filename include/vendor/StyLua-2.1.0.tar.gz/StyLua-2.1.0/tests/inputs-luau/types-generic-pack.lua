type X = {
	useMemo: <T...>(nextCreate: () -> T..., deps: Array<any> | nil) -> T...,
}
