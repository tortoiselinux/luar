function foo(
	bar: number,
	baz: number -- test
): number
	print("test")
end