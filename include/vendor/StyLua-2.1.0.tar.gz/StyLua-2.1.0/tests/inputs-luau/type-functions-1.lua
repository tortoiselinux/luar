type function Foo(x)
end

export type function Foo(x)
end
