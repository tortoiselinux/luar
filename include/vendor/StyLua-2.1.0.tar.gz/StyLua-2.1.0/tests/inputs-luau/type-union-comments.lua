-- https://github.com/JohnnyMorganz/StyLua/issues/351
export type ReactNode =
  React_Element<any>
  | ReactPortal
--   | ReactText
  | ReactFragment
--   | ReactProvider<any>
--   | ReactConsumer<any>
