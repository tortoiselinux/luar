function foo(): (
	nil -- Some comment
)
	return nil
end

type X = (
	string,
	number -- testing
) -> (
	number,
	string -- testing
)
