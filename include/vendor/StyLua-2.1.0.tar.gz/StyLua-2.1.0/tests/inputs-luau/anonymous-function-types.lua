local Object = {ClassName = "Object"}
Object.__tostring = function(self) return self.ClassName end

Object.__tostring = function(self): string
    return self.ClassName
end