export type Foo = {
	test: boolean -- true
}
