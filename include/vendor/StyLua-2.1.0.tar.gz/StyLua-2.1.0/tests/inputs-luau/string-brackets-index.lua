local foo = {
	[ [[test]] :: test ] = true,
}

foo[ [[test]] :: test ] = false
