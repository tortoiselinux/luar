local foo = bar;
(foo :: number).length = true