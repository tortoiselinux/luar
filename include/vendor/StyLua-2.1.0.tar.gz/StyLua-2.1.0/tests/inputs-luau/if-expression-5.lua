-- https://github.com/JohnnyMorganz/StyLua/issues/582
do
	do
		local defaultValue = if aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
			then aaaaaaaaaaaa(bbbbbbbbbb(cccccccccccccccccccccccccccccccccccc :: string), type_ :: dddddddddddddddddddddd)
			else nil
	end
end
