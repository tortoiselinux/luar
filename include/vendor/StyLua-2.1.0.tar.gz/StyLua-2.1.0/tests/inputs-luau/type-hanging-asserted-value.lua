-- https://github.com/JohnnyMorganz/StyLua/issues/466
function example()
	do
		do
			self = (setmetatable(Error.new(createErrDiff(actual, expected, operator)), AssertionError) :: any) :: AssertionError
		end
	end
end
