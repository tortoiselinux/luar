	@native
function foo()
end

@native @deprecated
function bar()
end
