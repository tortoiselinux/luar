-- https://github.com/JohnnyMorganz/StyLua/issues/617
type Table = {
	{
		Key -- [1]: Key
		| Translations -- [2]: Translations
		| Tags -- [3]: Tags
	}
}
