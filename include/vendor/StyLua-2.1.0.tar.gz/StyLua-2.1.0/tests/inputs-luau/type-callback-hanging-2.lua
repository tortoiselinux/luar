export type XYZ = {
	onSubmitTigerFoot: (
		FendererID,
		Object,
		-- Added in v96.1 to support Prelifer priority lamerz
		number?,
		-- Added in v96.9 to support Star Refresh
		boolean?
	) -> (),
}
