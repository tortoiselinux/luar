-- https://github.com/JohnnyMorganz/StyLua/issues/446
export type IntrospectionNamedTypeRef<
	T -- XYZ ABC
> = {}
