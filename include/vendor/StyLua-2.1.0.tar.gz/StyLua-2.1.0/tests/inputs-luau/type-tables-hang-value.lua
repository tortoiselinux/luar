-- https://github.com/JohnnyMorganz/StyLua/issues/394
export type DehydratedData = {
	cleaned: Array<Array<string | number>>,
	data: string | Dehydrated | Unserializable | Array<Dehydrated> | Array<Unserializable> | { [string]: string | Dehydrated | Unserializable },
	unserializable: Array<Array<string | number>>,
}
