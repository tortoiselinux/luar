local x =    @native  function()
end

local y = @native   @deprecated function()
end
