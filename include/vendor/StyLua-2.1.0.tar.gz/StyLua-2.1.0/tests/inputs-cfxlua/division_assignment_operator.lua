local num = 10
num /= 2