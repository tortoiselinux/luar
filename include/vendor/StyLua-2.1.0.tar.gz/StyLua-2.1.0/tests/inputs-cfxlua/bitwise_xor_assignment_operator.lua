local num = 5
num ^= 3