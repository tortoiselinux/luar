local num = 1
num <<= 2
