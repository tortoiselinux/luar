local t = {
  a = 1,
  b = 2,
  c = 3
}

local a, b, c in t