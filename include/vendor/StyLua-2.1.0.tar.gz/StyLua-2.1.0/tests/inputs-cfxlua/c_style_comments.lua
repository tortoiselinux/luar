print("Hello, World!") /* Comment */
/*
Multi
Line
Comment
*/