local ten = 10
ten -= 5
