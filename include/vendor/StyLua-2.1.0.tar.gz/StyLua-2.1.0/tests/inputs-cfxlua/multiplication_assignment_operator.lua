local base = 10
base *= 2
