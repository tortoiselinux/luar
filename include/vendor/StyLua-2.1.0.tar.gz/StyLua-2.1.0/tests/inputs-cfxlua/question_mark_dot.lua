local a = {
  b = 1,
  c = 2,
  d = {
    e = 3
  }
}

local x = a?.b
local y = a?.d?.e
