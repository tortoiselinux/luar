local num = 4
num >>= 2