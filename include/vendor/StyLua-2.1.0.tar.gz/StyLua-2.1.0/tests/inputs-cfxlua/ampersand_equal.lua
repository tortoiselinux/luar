local num = 6
num &= 3