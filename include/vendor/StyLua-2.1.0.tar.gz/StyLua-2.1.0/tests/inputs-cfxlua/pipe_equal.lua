local num = 4
num |= 1
