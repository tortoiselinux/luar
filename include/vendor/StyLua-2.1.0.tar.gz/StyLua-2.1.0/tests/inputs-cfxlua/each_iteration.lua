local t = { 1, 2, 3 }
for k, v in each(t) do print(k, v) end
