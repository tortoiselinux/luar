local a <const> = 5
local d <close>
local e <const>, f <close> = 1, 2
local g <const>, h <close>
local i <const>, j, k <close>
