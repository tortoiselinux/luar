local a <attribute_with_random_name> = 1
