return function()
	foo(function()
		local foo = {
			foooooooBar = true,
			barrrrrrrr = false,
			bazzzzzzzzzzzz = false
		}

		local data = {
			foooooooobarrr = {
				bazzzzzzzzing = {
					abadndafffffffff = "baszzzzzzzzzzfooooo",
				},
				singalong = nil,
				configurationn = nil,
				moreeeeDATA = {
					{
						foooo1 = "DATATA",
						fooooo2 = "SomethingElse",
						areWeThereYet = false,
						informationnn = {
							{
								moreItemss = "yessss",
								thisAndThat = {},
								foobarrrr = {
									kind = "thsasdfa",
									name = "pOEFKAPMAF",
									farfga = nil,
								},
								aleknfapwringa = false,
								ckvjnloanopfear = nil,
							},
						},
						aoeiwnaofnaewofw = nil,
						maavajneaafj = {},
						apringparnga = nil,
						lkxzncvlknpaga = nil,
					},
					{
						foooo1 = "DATATA",
						fooooo2 = "SomethingElse",
						areWeThereYet = false,
						informationnn = {
							{
								moreItemss = "yessss",
								thisAndThat = {},
								foobarrrr = {
									kind = "thsasdfa",
									name = "pOEFKAPMAF",
									farfga = nil,
								},
								aleknfapwringa = false,
								ckvjnloanopfear = nil,
							},
						},
						aoeiwnaofnaewofw = nil,
						maavajneaafj = {},
						apringparnga = nil,
						lkxzncvlknpaga = nil,
					},
					{
						arbanrklagarga = "ASORGNAWRN;",
						asdvaea = "SAGRAGARG",
						sadvaeafa = nil,
						eagawrgarfvsadv = {
							{
								zragar = "tnaesfsadfae",
								asdefa = {},
								faaega = {
									foo = "BARRRR",
									dasgeara = "DAKSJGNAKRJ",
									ofType = nil,
								},
								wafargasfgvas = false,
								aefawedfsafewad = nil,
							},
							{
								arbharba = "rfrsbaa",
								dsavWEASVDSA = {},
								ARNAESFBdsa = {
									eawfdsafawe = "DARAaADEGA",
									basdfaewf = nil,
									dsaarbasdfaefasdf = {
										easfdasf = "fdabaeA",
										sdavawef = nil,
										dfasfeasdf = {
											easdfaesd = "asrbharrba",
											eas = nil,
											easdfaesf = {
												aefdsadfae = "AFBARGAS",
												asdfasedf = "SDFAEASDF",
												asdfeeasdfaesa = nil,
											},
										},
									},
								},
								afcvaefasdfaesdfaes = false,
								asdgaergasdfae = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
						},
						DSAVGAWE = nil,
						casdczxcvae = {},
						awsdgawrga = nil,
						sadfasedfaesd = nil,
					},
					{
						afbasdfvase = "DSAGAESDF",
						adfbarfase = "FASDFAESDF",
						dsafaesdfaesadf = nil,
						fiunsies = {
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
										somethingElse = {
											fooo = bar,
											barrr = bazzz,
											fooobarr = {
												hello = true
											}
										}
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
										somethingElse = {
											fooo = bar,
											barrr = bazzz,
											fooobarr = {
												hello = true
											}
										}
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
										somethingElse = {
											fooo = bar,
											barrr = bazzz,
											fooobarr = {
												hello = true
											}
										}
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
										somethingElse = {
											fooo = bar,
											barrr = bazzz,
											fooobarr = {
												hello = true
											}
										}
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
										somethingElse = {
											fooo = bar,
											barrr = bazzz,
											fooobarr = {
												hello = true
											}
										}
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
							{
								foooo1 = "DATATA",
								fooooo2 = "SomethingElse",
								areWeThereYet = false,
								informationnn = {
									{
										moreItemss = "yessss",
										thisAndThat = {},
										foobarrrr = {
											kind = "thsasdfa",
											name = "pOEFKAPMAF",
											farfga = nil,
										},
										aleknfapwringa = false,
										ckvjnloanopfear = nil,
									},
								},
								aoeiwnaofnaewofw = nil,
								maavajneaafj = {},
								apringparnga = nil,
								lkxzncvlknpaga = nil,
							},
						},
						ragasdfaesfaes = nil,
						DSAGASDVAF = {},
						AASDFAEdsafea = nil,
						sadgaefasfeasdfase = nil,
					},
				},
			},
		}
	end)
end
